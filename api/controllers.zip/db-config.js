/**
 * Database configuration details
 */

//dbconfig for local 
const Config = {
    host: "localhost",
    username: "root",
    password: "",
    database: "phone_catalog", // add database name
    syncDB:true,
    port:3306
};
//export configuration variable.
module.exports = Config;

