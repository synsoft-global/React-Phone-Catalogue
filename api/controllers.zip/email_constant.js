const emailConfigs = {
    LOGO_URL :""  //add logo 
  };
  module.exports = emailConfigs;
  