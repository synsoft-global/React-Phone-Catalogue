const Config = {
  pageSize: 10, 
  TOKEN_EXPIRATION_TIME: 24 * 60 * 60, // 24 hours,
  jwt_secret: "demo", // add your secaret key
};

module.exports = Config;
